({
	
     showToast : function(type, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": type + "!",
            "type": type,
            "message": message
            
        });
        toastEvent.fire();
    },
    
    callCalculathelper: function(component, event, selectedRecord, terminationDate){
        
        var action = component.get("c.calculate");
        
        action.setParams({
            'unitRecord': selectedRecord,
            'terminationDate':terminationDate 
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                alert('result = '+JSON.stringify(result));
                component.set("v.calculatorsWrp", result);
            }
            
        }); 
        $A.enqueueAction(action);
        
    }
})