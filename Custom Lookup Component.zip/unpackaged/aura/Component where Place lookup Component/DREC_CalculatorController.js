({
	init : function(component, event, helper) {
		
        
        component.set('v.columns', [
            {label: 'Unit Name', fieldName: 'Unit_Name', type: 'text'},
            {label: 'Rent Return', fieldName: 'Rent_Return', type: 'text'},
            {label: 'VAT Return', fieldName: 'VAT_Return', type: 'text'},
            {label: 'Bank Fees', fieldName: 'Bank_Fees', type: 'text'},
            {label: 'Penalty', fieldName: 'Penalty', type: 'Date',editable : 'true'}
        ]);
        
	},
    
    calculateAction: function(component, event, helper) {
        var selectedRecord = component.get('v.selectedRecordId');
        var terminationDate = component.get("v.terminationDate");
        
       // alert('selectedRecord = '+JSON.stringify(component.get('v.selectedRecordId')));
       // alert('terminationDate = '+component.get("v.terminationDate"));
        
        if( ($A.util.isUndefinedOrNull(selectedRecord) || $A.util.isEmpty(selectedRecord)) &&
           (terminationDate == null || terminationDate == '') ){
            helper.showToast('Error','Please select Unit And Termination Date.');
            
        }else if($A.util.isUndefinedOrNull(selectedRecord) || $A.util.isEmpty(selectedRecord)){
            helper.showToast('Error','Please select Unit.');
            
        }else if(terminationDate == null || terminationDate == ''){
            helper.showToast('Error','Please select Termination Date.');
        }else{
            helper.callCalculathelper(component, event, selectedRecord, terminationDate );
        }
        
    }
})